package net.silentchaos512.gems.client.render.tile;

import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.silentchaos512.gems.SilentGems;
import net.silentchaos512.gems.lib.EnumModParticles;
import net.silentchaos512.gems.tile.TileChaosNode;

public class RenderTileChaosNode extends TileEntitySpecialRenderer<TileChaosNode> {

  @Override
  public void renderTileEntityAt(TileChaosNode te, double x, double y, double z, float partialTicks,
      int destroyStage) {

  }
}
