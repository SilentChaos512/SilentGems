package net.silentchaos512.gems.lib;

public enum EnumModParticles {

  CHAOS,
  CHAOS_PROJECTILE_BODY;
}
