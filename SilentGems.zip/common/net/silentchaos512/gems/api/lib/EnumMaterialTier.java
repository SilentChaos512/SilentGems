package net.silentchaos512.gems.api.lib;

public enum EnumMaterialTier {

  MUNDANE, REGULAR, SUPER
}
