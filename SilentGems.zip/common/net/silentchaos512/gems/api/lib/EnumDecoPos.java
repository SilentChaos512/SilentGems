package net.silentchaos512.gems.api.lib;

public enum EnumDecoPos {

  WEST, NORTH, EAST, SOUTH;
}
